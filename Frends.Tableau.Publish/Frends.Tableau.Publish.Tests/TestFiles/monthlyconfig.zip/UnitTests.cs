namespace Frends.Tableau.Publish.Tests;

using Frends.Tableau.Publish.Definitions;
using Microsoft.VisualBasic;
using NUnit.Framework;

[TestFixture]
internal class UnitTests
{
    [Test]
    public void Test()
    {
        var input = new Input
        {

            Url = "https://prod-uk-a.online.tableau.com/api/api-version/sites/jefim-6c59195d11/datasources",
            //Url = "https://prod-uk-a.online.tableau.com/api/api-version/sites/jefim-6c59195d11/datasources",
            HyperFiles = new string[] { "C:\\Users\\tossate\\source\\repos\\Frends.Tableau\\Frends.Tableau.Publish\\Frends.Tableau.Publish.Tests\\sample.hyper" },
        PublishPath = "C:\\Users\\tossate\\source\\repos\\Frends.Tableau\\Frends.Tableau.Publish\\Frends.Tableau.Publish.Tests\\monthlyconfig.xml",
            SiteId = "",
            Token = "HPxObaX3Tg2j5Bw2LnAT1g==:mNdpnNZRI90XdaqRWLIqN2mnfOGimOeA",
        };

        var options = new Options
        {
            Amount = 3,
            Delimiter = ", ",
        };

        var ret = Tableau.Publish(input, options, default);

        //Assert.That(ret.Output, Is.EqualTo("foobar, foobar, foobar"));
    }
}